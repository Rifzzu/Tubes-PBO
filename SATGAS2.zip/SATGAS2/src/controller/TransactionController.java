package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Transaction;

public class TransactionController {
    private final Transaction model;
    
    
    public TransactionController(Transaction model) {
        this.model = model;
    }
    


}
