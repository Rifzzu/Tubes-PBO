/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import model.CashBalance;
import model.Investor;

/**
 *
 * @author khali
 */
public class CashBalanceController {
    private CashBalance model;
    private Investor Model;

    public CashBalanceController(CashBalance model, Investor Model) {
        this.model = model;
        this.Model = Model;
    }

    public CashBalanceController(CashBalance model) {
        this.model = model;
    }
    
    public void topUp() throws Exception{
        model.topUp();
    }
    
    public void withdrawal() throws Exception {
        model.withdrawal();
    }
    
    public int getDataFromDB() throws Exception {
        return model.getDataFromDB();
    }
    
    public void setUser() throws Exception {
        model = new CashBalance(Model);
    }
}
