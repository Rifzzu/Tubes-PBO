/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Investor;
import model.Portfolio;
import model.Stock;
import model.TabelStock;
import model.Transaction;
import view.Stock_Investor;

/**
 *
 * @author user
 */
public class InvestorController {
    private final Investor model;
    private Stock modelStock;
    private ArrayList<Stock> listStock;
    private ArrayList <Transaction> listTransaksi;
    private ArrayList <Portfolio> listPortfolio;
    Stock_Investor formStock;

    public InvestorController(Investor model) {
        this.model = model;
    }
    public void Login() throws Exception{
        model.Login(model.getUsername(), model.getPassword());
    }
    
    public void buyStock() throws SQLException, Exception{
        model.buyStock();
    }
    
    public void sellStock() throws Exception{
        model.sellStock();
    }

    public ArrayList<Stock> getListStock() {
        return listStock;
    }

    public void setListStock() throws SQLException {
        Stock saham = new Stock();
        StockController caught = new StockController(saham);
        model.setListStock(caught.getDataFromDB());
    }
    
    public ArrayList getDataTransaction() throws SQLException, Exception{
        listTransaksi = (ArrayList<Transaction>) model.getDataTransaction();
        return listTransaksi;
    }
    
    public ArrayList getDataPortoflio() throws SQLException, Exception{
        listPortfolio = (ArrayList<Portfolio>) model.getDataPortoflio();
        return listPortfolio;
    }
  
    public InvestorController(Investor model, Stock_Investor formStock) {
        this.formStock = formStock;
        this.model = model;
        modelStock = new Stock();
    }
    public void isiTabel() throws Exception{
        listStock = modelStock.getDataFromDB();
        TabelStock ts = new TabelStock(listStock);
        formStock.getTable().setModel(ts);
    }

}
