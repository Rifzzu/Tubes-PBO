/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import model.Guest;

/**
 *
 * @author user
 */
public class GuestController {
    private Guest model;

    public GuestController(Guest model) {
        this.model = model;
    }
    
    public void Register(String nama_lengkap, String username, String password, String email) throws SQLException{
        model.Register(nama_lengkap, username, password, email);
    }
}
