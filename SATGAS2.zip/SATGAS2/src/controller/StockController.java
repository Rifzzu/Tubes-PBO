/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Stock;

/**
 *
 * @author user
 */
public class StockController {
    private Stock model;
    private ArrayList<Stock> listStock;

    public StockController(Stock model) {
        this.model = model;
    }
    
    public ArrayList<Stock> getDataFromDB() throws SQLException{
        listStock = model.getDataFromDB();
        return listStock;
    }
    

}
