package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import model.Portfolio;

public class PortfolioController {
    private Portfolio model;
    
    public PortfolioController(Portfolio model) {
        this.model = model;
    }
  
}
