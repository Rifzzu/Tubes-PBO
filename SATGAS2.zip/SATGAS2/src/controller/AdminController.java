/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Admin;
import model.Stock;
import model.TabelStock;
import view.ManageStock_Admin;

public class AdminController {
    private Admin model;
    private Stock modelStock;
    private ArrayList<Stock> listStock;
    ManageStock_Admin formManageStock;
    
    public AdminController(Admin model) {
        this.model = model;
    }
    public AdminController(Admin model, ManageStock_Admin formManageStock) {
        this.formManageStock = formManageStock;
        this.model = model;
        modelStock = new Stock();
    }
    
    public void addStock() throws SQLException{
        model.addStock(model.getKodeSaham(), model.getNamaSaham(), model.getHarga());
    }
    
    public void Login() throws Exception{
        model.Login(model.getUsername(), model.getPassword());
    }
    
    public void isiTabel() throws Exception{
        listStock = modelStock.getDataFromDB();
        TabelStock ts = new TabelStock(listStock);
        formManageStock.getTable().setModel(ts);
    }
}
