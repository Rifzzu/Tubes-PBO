/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package satgas;

import controller.AdminController;
import controller.GuestController;
import controller.InvestorController;
import controller.PortfolioController;
import controller.StockController;
import controller.TransactionController;
import controller.UserController;
import java.sql.SQLException;
import java.util.ArrayList;
import model.Admin;
import model.Guest;
import model.Investor;
import model.Portfolio;
import model.Stock;
import model.Transaction;
import model.User;

/**
 *
 * @author user
 */
public class SATGAS {

    /**
     * @param args the command line arguments
     * @throws java.sql.SQLException
     */
    public static void main(String[] args) throws SQLException, Exception {
        //Guest Model = new Guest();
        //GuestController controller = new GuestController(Model);
        
        //controller.Register("Khalid", "opor", "opor", "op@gmail.com");
        
        //User Model = new User("opor", "opor");
        //UserController controller = new UserController(Model);
        
        //controller.Login(Model.getUsername(), Model.getPassword());
        //System.out.println(Model.getNama());
        
        //User Model = new User("opor", "opor");
        //UserController controller = new UserController(Model);
        
        //controller.Login(Model.getUsername(), Model.getPassword());
        //controller.ChangePassword("Udin");
        
        //User Model = new User("opor", "Udin");
        //UserController controller = new UserController(Model);
        
        //controller.Login(Model.getUsername(), Model.getPassword());
        //controller.deleteAccount("Udin", "Udin");
        //System.out.println(Model.getNama());
        
        /*Investor Model = new Investor("asd", "dsa");
        InvestorController controller = new InvestorController(Model);
        
        controller.Login();
        
        System.out.println(Model.getRole());
        
        InvestorController con = new InvestorController(Model);
        ArrayList <Transaction> listTransaksi = new ArrayList<>(con.getDataTransaction());
        listTransaksi.forEach((element) -> {
            System.out.println(element.getKodeSaham());
        });*/
        
        /*Stock saham = new Stock();
        StockController con = new StockController(saham);
        saham.setListStock(con.getDataFromDB());
        
        saham.showStock();*/
        
        /*Stock saham = new Stock();
        StockController con = new StockController(saham);
        saham.setListStock(con.getDataFromDB());
        
        ArrayList<Stock> data = new ArrayList<>(saham.getListStock());
        
        for (int i = 0; i < 5; i++) {
            System.out.println(data.get(i).getKodeSaham());
        }*/
        
        /*Admin admin = new Admin();
        admin.setKodeSaham("IGNT");
        admin.setNamaSaham("IGNORANT");
        admin.setHarga((int) (Math.random() * (40000 - 50 + 1) + 50));
       
        Stock saham = new Stock();
        StockController caught = new StockController(saham);
        
        AdminController con = new AdminController(admin);
        admin.setSaham(caught.getDataFromDB());
        con.addStock();*/
        
        /*Investor Model = new Investor("asd", "dsa");
        InvestorController controller = new InvestorController(Model);
        
        controller.Login();
        
        ArrayList <Portfolio> listPortfolio = new ArrayList<>(controller.getDataPortoflio());
        
        listPortfolio.forEach((element) -> {
            System.out.println(element.getKodeSaham());
        });*/
        
        Investor Model = new Investor("rif", "1");
        InvestorController controller = new InvestorController(Model);
        
        controller.Login();
        controller.setListStock();
        controller.getDataTransaction();
        Model.setKode_saham("BBCA");
        Model.setLot(2);
        //controller.buyStock();
    }
    
}
