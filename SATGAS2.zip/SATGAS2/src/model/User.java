/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author user
 */
public class User {
    private String username;
    private String nama;
    private String password;
    private String email;
    private String role;

    public User(String username, String nama, String password, String email, String role) {
        this.username = username;
        this.nama = nama;
        this.password = password;
        this.email = email;
        this.role = role;
    }
    
    public User(String Username, String password) throws Exception{
        this.username = Username;
        this.password = password;
    }
    
    public void Login(String username, String password) throws Exception{
        Connection con = db.getConnection();
        PreparedStatement st = con.prepareStatement("SELECT * FROM user WHERE (username = ?) AND (password = ?);");
        st.setString(1, username);
        st.setString(2, password);
        
        ResultSet rs = st.executeQuery();
        if (!rs.next()) {
            throw new Exception("User tidak ditemukan");
        }

        System.out.println("Anda masuk sebagai Investor.");
        
        this.username = rs.getString(3);
        this.nama = rs.getString(2);
        this.password = rs.getString(4);
        this.email = rs.getString(7);
        this.role = rs.getString(5);
        
        //return new User(rs.getString(3), rs.getString(2), rs.getString(4), rs.getString(7), rs.getString(5));
    }
    
    public String ChangePassword(String password) throws Exception{
        try (Connection con = db.getConnection()) {
            PreparedStatement st = con.prepareStatement("UPDATE user set password = '"+password+"' WHERE username = '"+this.username+"';");
            st.executeUpdate();
            return password;
        }
    }
    
    public void deleteAccount(String password, String password_confirm)throws Exception{
        if (password.equals(password_confirm)){
            Connection con = db.getConnection();
            PreparedStatement st = con.prepareStatement("DELETE FROM history where username = '"+this.username+"'");
            st.executeUpdate();
            PreparedStatement st2 = con.prepareStatement("DELETE FROM user where username = '"+this.username+"'");
            st2.executeUpdate();
        }

    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
    
    
    
    
    
    
}
