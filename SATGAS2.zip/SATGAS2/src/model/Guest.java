/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author user
 */
public class Guest {
    public void Register(String nama_lengkap, String username, String password, String email) throws SQLException {
        try (Connection conn = db.getConnection()) {
            PreparedStatement st = conn.prepareStatement("INSERT INTO user (nama_lengkap, username, password, level, saldo, email) VALUES (?, ?, ?, ?, ?, ?);");
            st.setString(1, nama_lengkap);
            st.setString(2, username);
            st.setString(3, password);
            st.setString(4, "investor");
            st.setInt(5, 0);
            st.setString(6, email);
            st.executeUpdate();
        }
    }  
}
