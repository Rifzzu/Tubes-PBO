package model;

import controller.CashBalanceController;
import controller.InvestorController;
import db.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author user
 */
public class Investor extends User{
    private String kode_saham;
    private String nama_saham;
    private int lot;
    private int saldo;
    private ArrayList<Portfolio> listPortfolio;
    private CashBalance cash;
    private ArrayList <Transaction> listTransaksi;
    private ArrayList <Stock> listStock;
    
    public Investor(String username, String password) throws Exception{
        super(username, password);
    }
    
    public List<Transaction> getDataTransaction() throws Exception{
        try(Connection con = db.getConnection()) {
            
            listTransaksi = new ArrayList<>();
            try{
                PreparedStatement st = con.prepareStatement("SELECT kode_saham, lot, harga, status, lot_sell_check FROM history WHERE username = ?");
                st.setString(1,getUsername());
                ResultSet rs = st.executeQuery();
                while(rs.next()){
                    Transaction transaksi = new Transaction();
                    transaksi.setKodeSaham(rs.getString("kode_saham"));
                    transaksi.setLot(rs.getInt("lot"));
                    transaksi.setHarga(rs.getInt("harga"));
                    transaksi.setStatus(rs.getString("status"));
                    transaksi.setLot_sell_check(rs.getInt("lot_sell_check"));
                    listTransaksi.add(transaksi);
                }
            }catch(SQLException ex){
                Logger.getLogger(Stock.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return listTransaksi;
    }
    
    public List<Portfolio> getDataPortoflio() throws Exception{
        Connection con = db.getConnection();
        listPortfolio = new ArrayList<>();
 
        try{
            PreparedStatement st = con.prepareStatement("SELECT * FROM history INNER JOIN saham on (saham.kode_saham = history.kode_saham) WHERE history.username = ? AND status = 'Buy' AND lot_sell_check > 0 AND lot_sell_check IS NOT NULL");
            st.setString(1,getUsername() );
            ResultSet rs = st.executeQuery();
            int totalHarga = 0;
            while(rs.next()){
                Portfolio portfolio = new Portfolio();
                portfolio.setKodeSaham(rs.getString("kode_saham"));
                portfolio.setLot(rs.getInt("lot"));
                int lot = rs.getInt("lot_sell_check");
                int harga = rs.getInt("harga");
                int avrprice = harga / (lot * 100);
                totalHarga += harga;
                int hargaNow = (lot*100)*harga;
                
                portfolio.setAverage(avrprice);
                portfolio.setValue(harga);  
                listPortfolio.add(portfolio);
            }
        }catch(SQLException ex){
            Logger.getLogger(Stock.class.getName()).log(Level.SEVERE, null, ex);
        }
        return listPortfolio;
    }
    
    public void buyStock() throws SQLException, Exception{

        Connection con = db.getConnection();
        
        this.cash = new CashBalance(this);
        CashBalanceController conn = new CashBalanceController(this.cash);
        setSaldo(conn.getDataFromDB());
        System.out.println(getSaldo());
        
        int harga = 0;
        for(Stock element: listStock){
            if(element.getKodeSaham().equals(getKode_saham())){
                int hargaSaham = element.getHarga();
                harga = (lot*100) * hargaSaham;
            } 
        }
        System.out.println(harga);
        int hargaUpdate = getSaldo() - harga;
        if (hargaUpdate > 0){
            if (listTransaksi.isEmpty()){
                String sql = "INSERT INTO history (id_transaction, kode_saham, lot, harga,  username, status, lot_sell_check) VALUES (NULL,'"+getKode_saham()+"', '"+getLot()+"', '"+harga+"','"+getUsername()+"', 'Buy', '"+getLot()+"')";
                PreparedStatement pstmt = con.prepareStatement(sql);
                pstmt.executeUpdate();

                sql = "UPDATE user SET saldo = '"+hargaUpdate+"' WHERE username = '"+getUsername()+"'";
                pstmt = con.prepareStatement(sql);
                pstmt.executeUpdate();
                setSaldo(hargaUpdate);
            } else {
                PreparedStatement p = con.prepareStatement("SELECT * FROM history WHERE username = '"+getUsername()+"' AND kode_saham = '"+getKode_saham()+"' AND status = 'Buy' AND lot_sell_check > 0");
                ResultSet rs = p.executeQuery();
                if(!rs.next()){
                    PreparedStatement p1 = con.prepareStatement("INSERT INTO history (id_transaction, kode_saham, lot, harga,  username, status, lot_sell_check) VALUES (NULL,'"+getKode_saham()+"', '"+getLot()+"', '"+harga+"','"+getUsername()+"', 'Buy', '"+lot+"')");
                    p1.executeUpdate();
                }else{
                    for(Transaction trans : listTransaksi){
                        PreparedStatement p2 = con.prepareStatement("SELECT * FROM history WHERE username = '"+getUsername()+"' AND kode_saham = '"+getKode_saham()+"' AND status = 'Buy' LIMIT 1");
                        ResultSet rs2 = p2.executeQuery();
                        if(rs2.next()){
                            PreparedStatement p3 = con.prepareStatement("INSERT INTO history (id_transaction, kode_saham, lot, harga,  username, status, lot_sell_check) VALUES (NULL,'"+getKode_saham()+"', '"+getLot()+"', '"+harga+"','"+getUsername()+"', 'Buy', NULL)");
                            p3.executeUpdate();
                            int hargaUpd = trans.getHarga() + harga;
                            PreparedStatement p4 = con.prepareStatement("UPDATE history SET harga ='"+hargaUpd+"' WHERE username = '"+getUsername()+"' AND kode_saham = '"+getKode_saham()+"' AND status = 'Buy' LIMIT 1");
                            p4.executeUpdate();
                            int lotUpd = lot + trans.getLot();
                            PreparedStatement p5 = con.prepareStatement("UPDATE history SET lot_sell_check ='"+lotUpd+"' WHERE username = '"+getUsername()+"' AND kode_saham = '"+getKode_saham()+"' AND status = 'Buy' AND lot_sell_check AND lot_sell_check != 0 LIMIT 1");
                            p5.executeUpdate();
                        }
                    }
                }
                PreparedStatement p6 = con.prepareStatement("UPDATE user SET saldo = '"+hargaUpdate+"' WHERE username = '"+getUsername()+"'");
                p6.executeUpdate();
                setSaldo(hargaUpdate);
            }
        }
        System.out.println(getSaldo());
    }
    
    public void sellStock()throws SQLException, Exception{
        Connection con = db.getConnection();
        
        this.cash = new CashBalance(this);
        CashBalanceController conn = new CashBalanceController(this.cash);
        setSaldo(conn.getDataFromDB());
        System.out.println(getSaldo());
        
        int harga = 0, hargaSaham = 0, hargaUpdate;
        
        for(Stock element: listStock){
            if(element.getKodeSaham().equals(getKode_saham())){
                hargaSaham = element.getHarga();
                harga = (lot*100) * hargaSaham;
            } 
        }
          
        for(Transaction trans : listTransaksi){
            int cekLot = trans.getLot_sell_check() - lot;
            if(cekLot == 0){
                hargaUpdate = getSaldo() + harga;
                PreparedStatement p1 = con.prepareStatement("UPDATE user SET saldo = '"+hargaUpdate+"' WHERE username = '"+getUsername()+"'");
                p1.executeUpdate();
                PreparedStatement p2 = con.prepareStatement("INSERT INTO history (id_transaction, kode_saham, lot, harga, username, status, lot_sell_check) VALUES (NULL,'"+getKode_saham()+"', '"+lot+"', '"+harga+"','"+getUsername()+"', 'Sell', NULL)");
                p2.executeUpdate();
                PreparedStatement p3 = con.prepareStatement("UPDATE history SET lot_sell_check='"+cekLot+"' WHERE username = '"+getUsername()+"' AND kode_saham = '"+getKode_saham()+"' AND status = 'Buy' LIMIT 1");
                p3.executeUpdate();
                
            }else if(cekLot > 0){
                
                PreparedStatement p4 = con.prepareStatement("UPDATE history SET lot_sell_check ='"+cekLot+"'WHERE kode_saham = '"+getKode_saham()+"' AND username = '"+getUsername()+"' AND status = 'Buy' limit 1");
                p4.executeUpdate();
                PreparedStatement p5 = con.prepareStatement("SELECT * FROM history WHERE username = '"+getUsername()+"' AND kode_saham = '"+getKode_saham()+"' AND status = 'Buy' AND lot_sell_check > 0 LIMIT 1");
                ResultSet rs2 = p5.executeQuery();
                if(rs2.next()){
                    harga = trans.getHarga() - (lot * 100) * hargaSaham;
                    if(harga < 0){
                        harga = (lot * 100) * hargaSaham;
                    }
                    PreparedStatement p6 = con.prepareStatement("UPDATE history SET harga ='"+harga+"' WHERE kode_saham = '"+getKode_saham()+"' AND username = '"+getUsername()+"' AND status = 'Buy' limit 1");
                    p6.executeUpdate();
                }
                harga = (lot * 100) * hargaSaham;
                hargaUpdate = getSaldo() + harga;
                PreparedStatement p7 = con.prepareStatement("UPDATE user SET saldo ='"+hargaUpdate+"' WHERE username = '"+getUsername()+"'");
                p7.executeUpdate();
                setSaldo(hargaUpdate);
                PreparedStatement p8 = con.prepareStatement("INSERT INTO history (id_transaction, kode_saham, lot, harga,  username, status, lot_sell_check) VALUES (NULL,'"+getKode_saham()+"', '"+lot+"', '"+harga+"','"+getUsername()+"', 'Sell', NULL)");
                p8.executeUpdate();
            }
            
        }
        System.out.println(getSaldo());    
    }

    public void setLot(int lot) {
        this.lot = lot;
    }

    public void setKode_saham(String kode_saham) {
        this.kode_saham = kode_saham;
    }

    public ArrayList<Transaction> getListTransaksi() {
        return listTransaksi;
    }

    public void setListTransaksi(ArrayList<Transaction> listTransaksi) {
        this.listTransaksi = listTransaksi;
    }

    public void setListStock(ArrayList<Stock> listStock) {
        this.listStock = listStock;
    }

    public String getKode_saham() {
        return kode_saham;
    }

    public void setListPortfolio(ArrayList<Portfolio> listPortfolio) {
        this.listPortfolio = listPortfolio;
    }

    public int getLot() {
        return lot;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }

    public CashBalance getCash() {
        return cash;
    }

    public void setCash(CashBalance cash) {
        this.cash = cash;
    }

    public String getNama_saham() {
        return nama_saham;
    }

    public void setNama_saham(String nama_saham) {
        this.nama_saham = nama_saham;
    }

    public ArrayList<Portfolio> getListPortfolio() {
        return listPortfolio;
    }

    public ArrayList<Stock> getListStock() {
        return listStock;
    }
    
}

