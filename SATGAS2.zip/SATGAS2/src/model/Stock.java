/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Stock {
    String kodeSaham;
    private String namaSaham;
    private int harga;
    private ArrayList<Stock> listStock;
    
    public ArrayList<Stock> getDataFromDB() throws SQLException{
        Connection con = db.getConnection();
        
        listStock = new ArrayList<>();
        PreparedStatement st = con.prepareStatement("SELECT * FROM saham");
        ResultSet rs = st.executeQuery();
        while(rs.next()){
            Stock data = new Stock();
            data.setKodeSaham(rs.getString("kode_saham"));
            data.setNamaSaham(rs.getString("nama_saham"));
            data.setHarga(Integer.parseInt(rs.getString("harga_saham")));
            listStock.add(data);
        }
        
        return listStock;
    }
    
    public void showStock(){
        listStock.forEach((element) -> {
            System.out.println(element.getKodeSaham());
        });
    }
    
    public String getKodeSaham() {
        return kodeSaham;
    }

    public void setKodeSaham(String kodeSaham) {
        this.kodeSaham = kodeSaham;
    }

    public String getNamaSaham() {
        return namaSaham;
    }

    public void setNamaSaham(String namaSaham) {
        this.namaSaham = namaSaham;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public void setListStock(ArrayList<Stock> listStock) {
        this.listStock = listStock;
    }

    public ArrayList<Stock> getListStock() {
        return listStock;
    }
    
    
    
    
    
}
