package model;

public class Transaction {
    String nama, kodeSaham, status;
    int lot, harga, lot_sell_check;
    Investor dataUser;

    public Investor getDataUser() {
        return dataUser;
    }

    public void setDataUser(Investor dataUser) {
        this.dataUser = dataUser;
    }
    
    public String getKodeSaham() {
        return kodeSaham;
    }

    public void setKodeSaham(String kodeSaham) {
        this.kodeSaham = kodeSaham;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getLot() {
        return lot;
    }

    public void setLot(int lot) {
        this.lot = lot;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public int getLot_sell_check() {
        return lot_sell_check;
    }

    public void setLot_sell_check(int lot_sell_check) {
        this.lot_sell_check = lot_sell_check;
    }
    
    
}
