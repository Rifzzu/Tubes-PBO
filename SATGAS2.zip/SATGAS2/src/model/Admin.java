/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 * @author user
 */
public class Admin extends User{
    String kodeSaham;
    private String namaSaham;
    private int harga;
    private ArrayList<Stock> saham;
    
    public Admin(String username, String password) throws Exception{
        super(username, password);
    }
    
    public void addStock(String kode_saham, String nama_saham, int harga) throws SQLException{
        Stock dataBaru = new Stock();
        Connection con = db.getConnection();
        
        dataBaru.setKodeSaham(kode_saham);
        dataBaru.setNamaSaham(nama_saham);
        dataBaru.setHarga(harga);
        
        if(!saham.contains(dataBaru.kodeSaham)){           
            String sql = "INSERT INTO saham (kode_saham, nama_saham, harga_saham) VALUES (?, ?, ?)";
            PreparedStatement stmt = con.prepareStatement(sql);
            stmt.setString(1,dataBaru.getKodeSaham());
            stmt.setString(2,dataBaru.getNamaSaham());
            stmt.setInt(3,dataBaru.getHarga());

            int rowsAffected = stmt.executeUpdate();
        }

    }

    public String getKodeSaham() {
        return kodeSaham;
    }

    public void setKodeSaham(String kodeSaham) {
        this.kodeSaham = kodeSaham;
    }

    public String getNamaSaham() {
        return namaSaham;
    }

    public void setNamaSaham(String namaSaham) {
        this.namaSaham = namaSaham;
    }

    public int getHarga() {
        return harga;
    }

    public void setHarga(int harga) {
        this.harga = harga;
    }

    public ArrayList<Stock> getSaham() {
        return saham;
    }

    public void setSaham(ArrayList<Stock> saham) {
        this.saham = saham;
    }
    
    
}
