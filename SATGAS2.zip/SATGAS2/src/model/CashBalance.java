/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import db.db;
import java.sql.*;

/**
 *
 * @author user
 */
public class CashBalance {
    private int amount;
    private Investor user;
    private int saldo;

    public CashBalance(Investor user) throws Exception {
        this.user = user;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
    
    public Investor getUser() {
        return user;
    }

    public int getSaldo() {
        return saldo;
    }

    public void setSaldo(int saldo) {
        this.saldo = saldo;
    }   
    
    public void topUp() throws Exception{
        Connection con = db.getConnection();
        
        int jumlah = saldo + getAmount();
        PreparedStatement st = con.prepareStatement("UPDATE user SET saldo ='"+jumlah+"' WHERE username = '"+user.getUsername()+"'");
        st.executeUpdate();
    }
    
    public void withdrawal() throws Exception {
        Connection con = db.getConnection();
        
        if (saldo > 0) {
            if (saldo > amount) {
                int jumlah = saldo - amount;
                PreparedStatement st = con.prepareStatement("UPDATE user SET saldo ='"+jumlah+"' WHERE username = '"+user.getUsername()+"'");
                st.executeUpdate();
            } else {
                throw new Exception("Saldo tidak cukup");
            }
        } else {
            throw new Exception("Anda tidak memiliki saldo");
        }
    }
    
    public int getDataFromDB() throws Exception {
        Connection con = db.getConnection();
        
        PreparedStatement st = con.prepareStatement("SELECT saldo FROM user WHERE (username = ?);");
        st.setString(1, user.getUsername());
        
        ResultSet rs = st.executeQuery();
        if (!rs.next()) {
            throw new Exception("User tidak ditemukan");
        }
        
        return rs.getInt("saldo");
    }
    
    public void setUser(Investor user) {
        this.user = user;
    }
}
